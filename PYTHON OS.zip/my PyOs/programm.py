import systemutils
osisrun = True
print("Hello! PyOs made by SeaBitQ")
while(osisrun):
	g = input("command >>> ")
	if g == "reset":
		systemutils.reset()
	elif g == "regist":
		systemutils.regist()
	elif g == "help":
		print("reset - clear all data in PyOs (not code)")
		print("regist - create accaunt")
		print("login - login to system")
		print("calculator - residual, sum, product")
		print("quit - shut down PyOs")
	elif g == "login":
		systemutils.login()
	elif g == "quit":
		print("Thank for using PyOs, goodbye!")
		osisrun = False
	elif g == "calculator":
		systemutils.calculator()
	else:
		print("Error, command not found")

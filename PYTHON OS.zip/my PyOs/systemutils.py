lo = 0
def reset():
	rna = open("name.txt", "w")
	rnaw = rna.write("")
	rna.close()
	rpa = open("password.txt", "w")
	rpaw = rpa.write("")
	rpa.close()
	rca = open("config_accaunt.txt", "w")
	rcaw = rca.write("0")
	rca.close()
def regist():
	cheac = open("config_accaunt.txt", "r")
	cheacr = cheac.read()
	cheac.close()
	if (cheacr == "0"):
		print("Create accaunt")
		namep = input("Name >>> ")
		password0p = input("Password >>> ")
		password1p = input("Password again >>> ")
		if (password0p == password1p):
			print("Accaunt created")
			passc = open("password.txt", "w")
			passw = passc.write(password0p)
			passc.close()
			namec = open("name.txt", "w")
			namew = namec.write(namep)
			namec.close()
			cac = open("config_accaunt.txt", "w")
			cacw = cac.write("1")
			cac.close()
		else:
			print("Error, passwords do not match")
	elif(cheacr == "1"):
		print("Error, you already have accaunt")
def login():
	global lo
	cheac = open("config_accaunt.txt", "r")
	cheacr = cheac.read()
	cheac.close()
	if (cheacr == "0"):
		print("Error, you have not accaunt")
	elif (cheacr == "1"):
		tna = open("name.txt", "r")
		tnar = tna.read()
		tna.close()
		tpa = open("password.txt", "r")
		tpar = tpa.read()
		tpa.close()
		epa = input("Password >>> ")
		if epa == tpar:
			print("Hello", tnar, "and welcom to PyOs!!!")
			lo = 1
		else:
			print("Password not true, try again")

def calculator():
	global lo
	if lo == 1:
		def summ():
			x = float(input("1 summar >>> "))
			y = float(input("2 summar >>> "))
			z = x + y
			print("sum >>>", z)
		def residual():
			x = float(input("decreasing >>> "))
			y = float(input("subtraction >>> "))
			z = x - y
			print("sum >>>", z)
		def product():
			x = float(input("1 multiplier >>> "))
			y = float(input("2 multiplier >>> "))
			z = x * y
			print("product >>>", z)
		def quotient():
			x = float(input("dividend >>> "))
			y = float(input("divisor >>> "))
			if y != 0:
				print("quotient >>>", z)
			elif y == 0:
				print("Error, can't be divided by zero")
		wha = input("mathematical action >>> ")
		if wha == "product":
			product()
		elif wha == "residual":
			residual()
		elif wha == "sum":
			summ()
		elif wha == "quotient":
			quotient()
	elif lo == 0:
		print("Error, you not login")
